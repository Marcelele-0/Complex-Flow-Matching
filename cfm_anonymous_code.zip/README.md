# Cylindrical Flow Matching: Geometry-Aware Complex-Valued MRI Synthesis

> **Supplementary Code for NeurIPS 2026 GDDL Workshop Submission**

---

## Overview

This repository contains the official, self-contained PyTorch implementation of **Cylindrical Flow Matching (CFM)** for complex-valued Magnetic Resonance Imaging (MRI) reconstruction and synthesis.

Existing complex-valued generative models naively embed signals in flat Euclidean space $\mathbb{C} \cong \mathbb{R}^2$, ignoring the circular topology of the signal's phase $S^1$. By the triangle inequality, chordal Euclidean paths collapse toward the origin ($|z_t| \le (1-t)|z_0| + t|z_1|$), causing severe destructive interference and phase seam artifacts. 

**Cylindrical Flow Matching** models the complex signal on the cylindrical product manifold $\mathcal{M} = \mathbb{R}^+ \times S^1$ equipped with the product metric $g = dA^2 + d\theta^2$. Geodesics transport amplitude and phase along independent shortest paths, eliminating phase singularities and preventing signal attenuation.

---

## Repository Structure

```text
├── conf/                     # Hydra configuration files
│   ├── dataset/              # Dataset parameters (SKM-TEA)
│   ├── manifold/             # Geometry configs (cylindrical vs euclidean)
│   ├── model/                # Architecture configs (Continuous trigonometric U-Net)
│   ├── training/             # Optimizer, loss, and schedule parameters
│   └── config.yaml           # Top-level Hydra entrypoint
├── src/cfm/
│   ├── data/                 # Complex MRI dataset, multi-slice loader, undersampling masks
│   ├── flow/                 # Conditional Flow Matching bridges, solvers (Heun 2nd-order), and Riemannian log maps
│   ├── manifolds/            # Cylindrical (R+ x S1) and Euclidean (R2) manifold implementations
│   ├── models/               # Continuous trigonometric embedding U-Net & attention layers
│   ├── utils/                # Geodesic Phase Error (GPE), PSNR, SSIM, NMSE, DC metrics
│   ├── train.py              # Training pipeline
│   ├── evaluate.py           # Quantitative evaluation pipeline (Table 1)
│   └── reconstruct.py        # Visual 2x4 reconstruction grid generator (Figure 2)
├── tests/                    # Comprehensive unit test suite (85 tests)
├── schedule_comparison.sh    # Script to run controlled Euclidean vs Cylindrical benchmark
├── pyproject.toml            # Project dependencies and packaging
└── uv.lock                   # Deterministic lockfile
```

---

## Installation & Environment Setup

This project uses modern Python packaging via `pyproject.toml` and supports both `uv` (recommended for speed and reproducibility) and standard `pip`.

### Option A: Using `uv` (Recommended)

```bash
# Clone/unzip repository and enter directory
cd anonymous_supplementary_code

# Install all dependencies and dev tools with exact lockfile
uv sync
```

### Option B: Using standard `pip` / `conda`

```bash
# Create and activate Python 3.11+ environment
conda create -n cfm python=3.11 -y
conda activate cfm

# Install package in editable mode
pip install -e .
pip install pytest
```

---

## Verification & Unit Tests

Run the complete suite of 85 unit tests to verify the differential geometry maps, circular metrics, Heun ODE solvers, and U-Net embeddings:

```bash
# Run tests with pytest
pytest tests/ -v
```

All 85 tests verify:
- Geodesic logarithmic map on $S^1$ and metric distance invariance.
- Continuous 3-channel trigonometric embedding $(A, \cos\theta, \sin\theta)$.
- Exact Data Consistency (DC) projection in k-space ($E_{\text{DC}} < 10^{-6}$).
- Second-order Heun predictor-corrector Riemannian ODE integration.
- Geodesic Phase Error (GPE) and angular metric computation.

---

## Reproducing Experiments

### 1. 1-Click Table 1 Benchmark

To train and evaluate both the Euclidean baseline and the Cylindrical model under strictly identical conditions:

```bash
./schedule_comparison.sh
```

### 2. Manual Training

**Train Cylindrical Flow Matching (Ours):**
```bash
python -m cfm.train manifold=cylindrical logging.experiment_name=cylindrical_run
```

**Train Euclidean Baseline ($\mathbb{R}^2$):**
```bash
python -m cfm.train manifold=euclidean logging.experiment_name=euclidean_run
```

### 3. Quantitative Evaluation (Table 1)

Evaluate on 4x Cartesian undersampled k-space with strict Data Consistency:

```bash
# Evaluate Cylindrical model
python -m cfm.evaluate manifold=cylindrical evaluate.run_name=cylindrical_run

# Evaluate Euclidean model
python -m cfm.evaluate manifold=euclidean evaluate.run_name=euclidean_run
```

### 4. Qualitative Reconstruction (Figure 2)

Generate 2x4 panel comparisons (Corrupted, Recon, GT, Error Maps for Magnitude & Phase):

```bash
python -m cfm.reconstruct manifold=cylindrical evaluate.run_name=cylindrical_run
```

---

## License & Anonymity

This archive is fully anonymized for double-blind peer review at the NeurIPS 2026 GDDL Workshop.
